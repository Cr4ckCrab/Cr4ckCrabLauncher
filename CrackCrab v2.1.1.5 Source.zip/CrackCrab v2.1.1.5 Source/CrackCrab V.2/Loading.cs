﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CrackCrab_V._2
{
    public partial class Loading : Form
    {
        private string baseDirectoryPlaceholder = "{crackcrab}";
        public Loading()
        {
            InitializeComponent();
        }

        private async void Loading_Load(object sender, EventArgs e)
        {
            progressBar.Value = 0;
            statusLabel.Text = "Hold on...";

            await Task.Delay(3000); // ir random

            await PreloadComponents();

            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

            string[] filesToCheck = {  Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "test", "test.exe"),};

            foreach (var filePath in filesToCheck)
            {
                string shortenedPath = filePath.Replace(currentDirectory, $"{baseDirectoryPlaceholder}\\");
                statusLabel.Text = $"Checking library... {shortenedPath}";
                await Task.Delay(500);

                if (!File.Exists(filePath))
                {
                    MessageBox.Show($"File not found: {filePath}\nLauncher might not be working properly.",
                                    "File Not Found", MessageBoxButtons.OK);

                    var result = MessageBox.Show("Do you want to continue?", "Continue or Close", MessageBoxButtons.YesNo);

                    if (result == DialogResult.No)
                    {
                        statusLabel.Text = "Closing down...";
                        progressBar.Value = 100;

                        for (int i = 100; i >= 0; i--)
                        {
                            progressBar.Value = i;
                            await Task.Delay(30);
                        }
                        this.Close();
                        return;
                    }
                }

                progressBar.Value += 100 / filesToCheck.Length;
            }

            // All files checked successfully
            statusLabel.Text = "Checking Config...";
            await Task.Delay(1000); // nebaigtas

            statusLabel.Text = "Booting Launcher...";
            await Task.Delay(3000); // random

            // Open the main form
            this.Hide();
            var infoform = new CrackCrab();
            infoform.Show();
        }
        private async Task PreloadComponents()
        {
            await Task.Delay(2000); // nebaigtas
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
